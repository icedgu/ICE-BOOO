//
//  PayViewController.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 14..
//  Copyright © 2018년 박신원. All rights reserved.
//

import UIKit
import Alamofire

class PayViewController: ViewController {
    
    
    @IBAction func goPreviewPageButton(_ sender: Any) {
        /*
         Alamofire.request("http://192.168.0.13/get_user_info.php").responseJSON{ response in
         
         // SUCCESS or FAILURE 값을 반환함. 주석처리해도 상관없음
         print(response)
         
         if let walletJSON = response.result.value {
         let walletObject:Dictionary = walletJSON as! Dictionary<String, Any>
         
         self.hdKeyObject = walletObject[MyViewController.key] as! String
         self.balanceObject = walletObject[MyViewController.balance] as! Double
         
         self.hdMasterKeyLabel.text = "\(self.hdKeyObject!)"
         self.accountBalanceLabel.text = "\(self.balanceObject!)"
         
         if(self.hdKeyObject != nil)
         {
         let _url = "http://192.168.0.13/hdkey_searching.php"
         let parameters: Parameters = [
         
         "HDmasterKey": self.hdKeyObject!
         ]
         
         Alamofire.request(_url,
         method: .post,
         parameters: parameters,
         encoding: URLEncoding.queryString ).responseJSON{ response in
         
         print(response)
         
         if let infoJSON = response.result.value{
         let infoObject:Dictionary = infoJSON as! Dictionary<String, Any>
         
         self.c_amount = infoObject[MyViewController.balance] as! Double
         
         self.chargingBalanceLabel.text = "\(self.c_amount!)"+"BTC"
         }
         
         
         
         }
         }
         
         }
         
         }*/
    }
    @IBAction func goCoinPayment(_ sender: Any) {
        /*---------------------------------------------------------------------------------------------
         
         :::WEB server에 url 전송:::
         
         btc_transaction.php 파일은 웹서버에 전송할 url을 통해 매개변수 값을 전달받음(receivedPubkey, receivedPrice)
         그렇기 때문에 앱에서 웹서버에 호출할 때 매개변수를 포함한 url 형태로 전송해야함
         
         ---------------------------------------------------------------------------------------------*/
        
        let _url = "http://10.90.1.241/btc_transaction.php"
        let parameters: Parameters = [
            
            "pubKey": segue_publicKey!,
            "price": segue_price!
        ]
        
        Alamofire.request(_url,
                          method: .post,
                          parameters: parameters,
                          encoding: URLEncoding.queryString )
        
        print("SUCCESS")
    }
    
    
    var hdKeyObject: String?
    @IBAction func goChargePayment(_ sender: Any) {
        // 해당 사용자의 hdmasterkey를 받아옴
        
        Alamofire.request("http://10.90.1.241/get_user_info.php").responseJSON{ response in
            print("Imin")
            // SUCCESS or FAILURE 값을 반환함. 주석처리해도 상관없음
            print(response)
            
            if let walletJSON = response.result.value {
                let walletObject:Dictionary = walletJSON as! Dictionary<String, Any>
                
                self.hdKeyObject = walletObject[MyViewController.key] as! String
                
                if(self.hdKeyObject != nil)
                {
                    print("실핼실핼")
                    let _url = "http://10.90.2.236/camount_transaction.php"
                    let parameters: Parameters = [
                        
                        //"pubKey": self.segue_publicKey!,
                        "price": self.segue_price!,
                        "hdmasterkey": self.hdKeyObject!
                    ]
                    
                    Alamofire.request(_url,
                                      method: .post,
                                      parameters: parameters,
                                      encoding: URLEncoding.queryString )
                    
                    print("SUCCESS")
                }
            }
        }
        
        
    }
    
    @IBOutlet weak var priceforPayLabel: UILabel!
    var segue_price: String?
    var segue_publicKey: String?
    
    //let viewController = ViewController()
    //let itemListTableView = ItemListTableView()
    //let itemListTableViewCell = ItemListTableViewCell()
    
    let payTabViewController = PayTabViewController()
    //let paymentStorage = PaymentStorage(coder: NSCoder)
    
    
    //let price = PaymentStorage.init(pubKey: "hell", price: "ee")
    
    
    
    
    //let price = payTabViewController.getTotalPrice
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(payTabViewController.getPublicKey)
        //print(payTabViewController.payinfo)
        priceforPayLabel.text = segue_price
        print(segue_publicKey!)
        print(segue_price!)
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    //    @IBAction func barCancelButton(_ sender: Any) {
    //        self.navigationController!.popViewController(animated: false)
    //    }
    
}
