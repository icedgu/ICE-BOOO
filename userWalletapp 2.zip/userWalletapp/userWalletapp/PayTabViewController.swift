//
//  PayTabViewController.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 15..
//  Copyright © 2018년 박신원. All rights reserved.
//

import UIKit
import AVFoundation
import QRCodeReader

class PayTabViewController: ViewController, QRCodeReaderViewControllerDelegate {
   
    
    let viewController = ViewController()
    public var payinfo : [String:Int] = [:]
    
    
    
    
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   QRCodeReaderViewControllerDelegate                      //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    func reader(_ reader: QRCodeReaderViewController, didScanResult result: QRCodeReaderResult) {
        reader.stopScanning()
        
        dismiss(animated: true) { [weak self] in
            /*
            let alert = UIAlertController(
                title: "QRCodeReader!!",
                message: String (format:"%@ (of type %@)", result.value, result.metadataType),
                preferredStyle: .alert
            )*/
            
            
//            let alertController = UIAlertController(title: "결제를 진행하겠습니까?", message: "\nsendto: " + "\(self?.getPublicKey!)!" + "\n" + "Total price:  " + "\(self?.getTotalPrice!)!" + " 코인", preferredStyle: .alert)
            
            let alertController = UIAlertController(
                title: "결제를 진행하겠습니까?",
                message: String(format: "Total Price: %@ coin \n send to %@", (self?.getTotalPrice!)!, (self?.getPublicKey!)!),
                preferredStyle: .alert)

            
            //alert.addAction(UIAlertAction(title:"OK", style: .Default, handler:  { action in self.performSegueWithIdentifier("mySegueIdentifier", sender: self) }
            
            alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in self?.performSegue(withIdentifier: "typeofPay", sender: self)
                // Ok 버튼을 눌렀을 때 실행
                
                //self.reader.startScanning()
            }))
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                // Cancel 버튼.
                //self.reader.startScanning()
                
            //alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            
            
        }))
            self?.present(alertController, animated: true, completion: nil)
    }
    }
    
    
    
    /*
     let alertController = UIAlertController(title: "결제를 진행하겠습니까?", message: "\nsendto: " + "\(self.getPublicKey!)" + "\n" + "Total price:  " + "\(self.getTotalPrice!)" + " 코인", preferredStyle: .alert)
     
     alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
     // Ok 버튼을 눌렀을 때 실행
     
     //self.reader.startScanning()
     }))
     alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
     // Cancel 버튼.
     //self.reader.startScanning()
     }))*/
    
    
    
    
    
    func readerDidCancel(_ reader: QRCodeReaderViewController) {
        reader.stopScanning()
        
        dismiss(animated: true, completion: nil)
    }
    
    func reader(_ reader: QRCodeReaderViewController, didSwitchCamera newCaptureDevice: AVCaptureDeviceInput) {
        print("Switching capturing to: \(newCaptureDevice.device.localizedName)")
    }
    

    
    
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   permission check! => alert 수정 !                        //
    //     -> 최초 앱 실행할 때 1번만                                 //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    private func checkScanPermissions() -> Bool {
        do {
            return try QRCodeReader.supportsMetadataObjectTypes()
        } catch let error as NSError {
            let alert: UIAlertController
            
            switch error.code {
            case -11852:
                alert = UIAlertController(title: "Error", message: "This app is not authorized to use Back Camera.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { (_) in
                    DispatchQueue.main.async {
                        if let settingsURL = URL(string: UIApplicationOpenSettingsURLString) {
                            UIApplication.shared.openURL(settingsURL)
                        }
                    }
                }))
                
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            default:
                alert = UIAlertController(title: "Error", message: "Reader not supported by the current device", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            
            present(alert, animated: true, completion: nil)
            
            return false
        }
    }
    
    
    
  
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   QRscansession                                           //
    //                                                           //
    //                                                           //
    //***********************************************************//
    @IBAction func scanPayQRButton(_ sender: Any) {
        print("pressed")
        paymentqrScansession()
        
        /*guard checkScanPermissions() else { return }
        
        readerVC.modalPresentationStyle = .formSheet
        readerVC.delegate               = self
        
        readerVC.completionBlock = { (result: QRCodeReaderResult?) in
            if let result = result {
                print("Completion with result: \(result.value) of type \(result.metadataType)")
            }
        }
        present(readerVC, animated: true, completion: nil)*/
        
        
    }
    
    
    
    //카메라로 스캔하면 alert창에 정보가 떠야행
    func paymentqrScansession()  {
        guard checkScanPermissions() else { return }
        
        readerVC.modalPresentationStyle = .formSheet
        readerVC.delegate               = self
        
        
        
        
        
        readerVC.completionBlock = { (result: QRCodeReaderResult?) in
            if let result = result  {
                print("Completion with result: \(result.value) of type \(result.metadataType)")
                
                self.scanQRinfo(getqrinfo: result.value)
                print(self.getPublicKey!)
                print(self.getTotalPrice as Any)
                print(self.payinfo)
                

                self.present(self.viewController, animated: true, completion: nil)
            }
        }
        present(readerVC, animated: true, completion: nil)
        
        }
        
    
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   QRscansession2                                          //
    //    -> value 튜플에 저장(url fragment)                        //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    var getPublicKey: String?
    var getTotalPrice: String?
    
    override func scanQRinfo(getqrinfo: String!) {
        //let getqrinfo = result.value
        func generateDictionalyFromUrlComponents(components: NSURLComponents) -> [String : String] {
            var fragments: [String : String] = [:]
            guard let payinfo = components.queryItems else {
                return fragments
            }
            for item in payinfo {
                fragments[item.name] = item.value
            }
            return fragments
        }
        
        let comp: NSURLComponents? = NSURLComponents(string: getqrinfo!)
        let fragments = generateDictionalyFromUrlComponents(components: comp!)
        //        print(fragments["price"]) // => Optional("12345")
        getPublicKey = fragments["publicKeyofProvider"]
        getTotalPrice = fragments["totalPrice"]
        addNewItem()
        
       
    }
    
    func addNewItem() {
        let new:PaymentStorage = PaymentStorage(pubKey: getPublicKey!, price: getTotalPrice!)
        
//        if (self.category.items?.append(new)) == nil {
//            self.category.items = [new]
//        }    // nil일 경우 새로운 항목이 들어간 배열을 넣어줌
     

    }
    
    //// 항목관련
    // 새로운 카테고리를 배열에 추가한 후 저장하기
    func addNewCategory(_: String) {
       // datasOfCenter.paymentStorage.append(getPublicKey!)
        //datasOfCenter.saveStorageCategories()
    }
    
    
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   Override function Lifecycle                             //
    //                                                           //
    //                                                           //
    //***********************************************************//
   // 탭바2의 카메라를 꺼줘야함
    override func viewWillAppear(_ animated: Bool) {
        
        viewController.reader.stopScanning()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        viewController.reader.stopScanning()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as? PayViewController
        destination?.segue_price = getTotalPrice!
        destination?.segue_publicKey = getPublicKey!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



