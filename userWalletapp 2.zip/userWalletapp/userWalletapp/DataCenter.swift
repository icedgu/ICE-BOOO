//
//  DataCenter.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 21..
//  Copyright © 2018년 박신원. All rights reserved.
//

import Foundation



class PaymentStorage:NSObject, NSCoding {
    var pubKey:String?
    var price: String?
    
    
    // payment 생성자
    init(pubKey: String, price: String) {
        self.pubKey = pubKey
        self.price = price
    }
//    override init() {
//        self.pubKey = pubKey
//        self.price = price
//    }
    

    
    required init?(coder aDecoder: NSCoder) {
        self.pubKey = aDecoder.decodeObject(forKey: "SCIPubKey") as? String
        self.price = aDecoder.decodeObject(forKey: "SCIPrice") as? String
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.pubKey, forKey: "SCIPubKey")
        aCoder.encode(self.price, forKey: "SCIPrice")
    }
}

let storageFile = "Storage.datas"

class DataCenter {
    // 데이터 저장 경로 지정
    var storageFilePath:String { get {
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        return documentDirectory + storageFile
        }}
    
    // 아카이브에서 읽어온 데이터 복사 공간
    var paymentStorage:[PaymentStorage] = []
    
    
    // 데이터 초기화
    func removeStorageCategories() {
        do {
            let fileManager = FileManager.default
            
            // Check if file exists
            if fileManager.fileExists(atPath: self.storageFilePath) {
                // Delete file
                try fileManager.removeItem(atPath: self.storageFilePath)
            } else {
                print("File does not exist")
            }
            
        }
        catch let error as NSError {
            print("An error took place: \(error)")
        }
    }
    
    
}

var datasOfCenter:DataCenter = DataCenter()
