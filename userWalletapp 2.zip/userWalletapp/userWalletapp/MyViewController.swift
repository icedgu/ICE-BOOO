//
//  MyViewController.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 15..
//  Copyright © 2018년 박신원. All rights reserved.
//


import UIKit
import Alamofire


class MyViewController: ViewController {
    
    
    @IBOutlet var hdMasterKeyLabel: UILabel!
    @IBOutlet var accountBalanceLabel: UILabel!
    @IBOutlet var chargingBalanceLabel: UILabel!
    
    
    static let key = "HDmasterkey"
    static let balance = "balance"
    
    var hdKeyObject:String?
    var balanceObject:Double?
    var c_amount:Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        /* -------------------------------------------------------------------------------------------
         
         :::WEB server에 접근:::
         
         Alomofire.request("your URL").responseJSON{  내용입력   }
         만약에 에러를 찾고 싶으면, responseString으로 바꾸고, debugPrint(response) 이렇게 변경
         
         
         *주  의*
         
         web server를 통해 불러올 php파일을 코딩할 때, 출력결과물은 JSON encode된 내용만 포함해야함
         다른 내용을 포함할 경우(ex. echo "이것은 테스트" 이런 문구) 불러올 때 에러가 생길 수 있음
         
         
         ------------------------------------------------------------------------------------------- */
        
        Alamofire.request("http://10.90.1.241/get_user_info.php").responseJSON{ response in
            
            // SUCCESS or FAILURE 값을 반환함. 주석처리해도 상관없음
            print(response)
            
            if let walletJSON = response.result.value {
                let walletObject:Dictionary = walletJSON as! Dictionary<String, Any>
                
                self.hdKeyObject = walletObject[MyViewController.key] as? String
                self.balanceObject = walletObject[MyViewController.balance] as? Double
                
                self.hdMasterKeyLabel.text = "\(self.hdKeyObject!)"
                self.accountBalanceLabel.text = "\(self.balanceObject!)"
                
                if(self.hdKeyObject != nil)
                {
                    let _url = "http://10.90.2.236/hdkey_searching.php"
                    let parameters: Parameters = [
                        
                        "HDmasterKey": self.hdKeyObject!
                    ]
                    
                    Alamofire.request(_url,
                                      method: .post,
                                      parameters: parameters,
                                      encoding: URLEncoding.queryString ).responseJSON{ response in
                                        
                                        print(response)
                                        
                                        if let infoJSON = response.result.value{
                                            let infoObject:Dictionary = infoJSON as! Dictionary<String, Any>
                                            
                                            self.c_amount = infoObject[MyViewController.balance] as? Double
                                            
                                            self.chargingBalanceLabel.text = "\(self.c_amount!)"+"BTC"
                                        }
     
                    }
                }
                
            }
            
        }

        
        print("\(hdKeyObject)")
        print(hdKeyObject)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
