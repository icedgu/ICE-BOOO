//
//  ItemListTableViewCell.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 14..
//  Copyright © 2018년 박신원. All rights reserved.
//

import UIKit

class ItemListTableViewCell: UITableViewCell {

    @IBOutlet weak var nameofItemLabel: UILabel!
    @IBOutlet weak var amountofItemLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
