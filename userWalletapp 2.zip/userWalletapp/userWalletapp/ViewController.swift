//
//  ViewController.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 13..
//  Copyright © 2018년 박신원. All rights reserved.
//

import UIKit
import AVFoundation
import QRCodeReader
import Alamofire

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
   //var tableView: UITableView  =   UITableView()
    var itemTotalPrice : Double = 0
    var addPrice : Double? = 0
    
    
    @IBOutlet weak var itemListTableView: UITableView!
    public var items : [String:Int] = [:]
    //var newScanitem: String!
    
    
    /*-----------------------------------------------------------------------------------
     
     :::WEB server에 딕셔너리 형태를 데이터베이스로 전송:::
     
     -----------------------------------------------------------------------------------*/
    @IBOutlet weak var itemTotalPriceLabel: UILabel!
    
    //사용자의 장바구니 리스트를 자판기로 전송하는 함수
    @IBAction func gotoDB(_ sender: Any) {
        
        let alertController = UIAlertController(title: "💗자판기로 전송💗", message: "\n 스캔한 아이템 리스트를 자판기로 보냅니다!\n결제 탭으로 이동해주세요~", preferredStyle: .alert)
        
            
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            // Ok 버튼을 눌렀을 때 실행
            print("I'M IN")
            
            let _url = "http://10.90.2.236/goto_db.php"
            
            for (key, value) in self.items {
                // dictionary 에 저장된 값을 db에 넣어주는 작업
                let parameters: Parameters = [
                    "pID": key,
                    "count": value
                ]
                
                Alamofire.request(_url,
                                  method: .post,
                                  parameters: parameters,
                                  encoding: URLEncoding.queryString )
                
                print("SUCCESS")
                
            }
            self.items = [:]
            self.items.removeAll(keepingCapacity: false)
            self.itemListTableView.reloadData()
            self.itemTotalPriceLabel.text = "itemTotalPrice"
            self.itemTotalPrice = 0
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            // Cancel 버튼을 눌렀을 때 실행할 코드를 넣어주시면 됩니다.
            //self.reader.startScanning()
        }))
        
        self.present(alertController, animated: true, completion: nil)
        
        
        
        
        
        
    }
    
    
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   결제 QR 바로 띄우는줄 ㅎㅎ                                    //
    //                                                           //
    //                                                           //
    //***********************************************************//
 
//    @IBAction func payButton(_ sender: Any) {
//        
//        let storyBoard = UIStoryboard(name:"Main", bundle: nil) //스토리보드 가져오기
//        let payViewController = storyBoard.instantiateViewController(withIdentifier: "payViewController") as! PayViewController //캐스팅
//        //payViewController.receivedValueFromBeforeVC = "테스트" //해당 뷰와 관련된 .swift 파일의 변수에 값 전달
//        //payViewController.value
//        self.present(payViewController, animated: true, completion: nil) //storyboardid가 IS_B인 화면 화면 띄움
//    }
//    

    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        print(segue.identifier!)
//
//        switch segue.identifier! {
//        case "paySegue":
//            let payViewController = segue.destination as! PayViewController
//            payViewController.delegate = self
//
//        default:
//            break
//        }
//    }
   

    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   TableView                                               //
    //                                                           //
    //                                                           //
    //***********************************************************//
    //아이템 개수 만큼 읽어와서 테이블의 cell개수를 감지 후 알맞은 정보를 cell에 뿌려주어야한다
    
    
    public func numberOfSections(in itemListTableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    public func tableView(_ itemListTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return items.count
    }
    
    //cell에 뿌리깅
    public func tableView(_ itemListTableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemListTableView.dequeueReusableCell(withIdentifier: "ItemListTableViewCell", for: indexPath) as! ItemListTableViewCell
        
        let itemNames = Array(items.keys)
        //print(itemNames)
        let itemName = itemNames[indexPath.row]
        //let itemName = self.items[(indexPath as NSIndexPath).row]
        cell.nameofItemLabel!.text = itemName
        if let amount:Int = items[itemName] {
            print("\(amount)")
            cell.amountofItemLabel!.text = "\(amount)"
        }
        return cell
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    func tableView(_ itemListTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
//    }
//
//    func tableView(_ itemListTableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = UITableViewCell()
//        cell.textLabel?.text = "\(indexPath.row)"
//
//        return cell
//    }
    
    
    
    

    

    
    
    


    //***********************************************************//
    //                                                           //
    //                                                           //
    //   reset button                                           //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    @IBAction func resetButton(_ sender: Any) {
        
        let alertController = UIAlertController(title: "😲목록을 초기화 하시겠습니까?", message: "\n 초기화 하면 모든 데이터가 사라집니다!!", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            // Ok 버튼을 눌렀을 때 실행
            self.items = [:]
            self.items.removeAll(keepingCapacity: false)
            self.itemListTableView.reloadData()
            //self.reader.startScanning()
            
            self.itemTotalPriceLabel.text = "itemTotalPrice"
            self.itemTotalPrice = 0
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            // Cancel 버튼을 눌렀을 때 실행할 코드를 넣어주시면 됩니다.
            //self.reader.startScanning()
        }))
        
        self.present(alertController, animated: true, completion: nil)
            }
    
    
    

    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   define previewView(QRscanCamera)                        //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    @IBOutlet weak var previewView: QRCodeReaderView! {
        didSet {
            previewView.setupComponents(showCancelButton: false, showSwitchCameraButton: false, showTorchButton: false, showOverlayView: true, reader: reader)
        }
    }
    
    
    //reader, readerVC 설정
    lazy var reader: QRCodeReader = QRCodeReader()
    lazy var readerVC: QRCodeReaderViewController = {
        let builder = QRCodeReaderViewControllerBuilder {
            $0.reader                  = QRCodeReader(metadataObjectTypes: [.qr], captureDevicePosition: .back)
            $0.showTorchButton         = true
            $0.preferredStatusBarStyle = .lightContent
            
            $0.reader.stopScanningWhenCodeIsFound = false
        }
        
        return QRCodeReaderViewController(builder: builder)
    }()
    
    //앱에서 카메라에 접근이 가능한 지에 대한 permission check!
    private func checkScanPermissions() -> Bool {
        do {
            return try QRCodeReader.supportsMetadataObjectTypes()
        } catch let error as NSError {
            let alert: UIAlertController
            
            switch error.code {
            case -11852:
                alert = UIAlertController(title: "Error", message: "This app is not authorized to use Back Camera.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { (_) in
                    DispatchQueue.main.async {
                        if let settingsURL = URL(string: UIApplicationOpenSettingsURLString) {
                            UIApplication.shared.openURL(settingsURL)
                        }
                    }
                }))
                
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            default:
                alert = UIAlertController(title: "Error", message: "Reader not supported by the current device", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            
            present(alert, animated: true, completion: nil)
            
            return false
        }
    }
    
    

    //***********************************************************//
    //                                                           //
    //                                                           //
    //   QRscansession                                           //
    //                                                           //
    //                                                           //
    //***********************************************************//
    //Sanc button : 살릴지 말지 고민듕 ㅎ
    @IBAction func scanItemButton(_ sender: Any) {
        //안살림~ 뷰에는 안보이게(hidden)으로 해놨습
    }
    //카메라로 스캔하면 alert창에 정보가 떠야행
    //카메라 스캔
    func qrScansession()  {
        guard checkScanPermissions() else { return }
        //뷰 열자마자 카메라 켜지는걸로.
        //qr 스캔 시작
        
        
        reader.startScanning()
        reader.didFindCode = { result in
            print("Completion with result: \(result.value) of type \(result.metadataType)")
            self.scanQRinfo(getqrinfo: result.value)
            print(self.getNameofItem!)
            print(self.getPriceofItem!)
            //self.newScanitem = result.value
            
            let alertController = UIAlertController(title: "구매 목록에 추가하시겠습니까?", message: "\nitem: " + "\(self.getNameofItem!)" + "\n" + "price:  " + "\(self.getPriceofItem!)" + " 코인", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                // Ok 버튼을 눌렀을 때 실행
                if self.items["\(self.getNameofItem!)"] != nil {
                    // 입력받은 값이 key값으로 이미 존재할 경우 amount 값만 1증가
                    print("Exist!")
                    let old = self.items["\(self.getNameofItem!)"]!;
                    self.items["\(self.getNameofItem!)"] = old + 1;
                    
                    //itemTotalPrice 가격 더하기
                    
                    
                    
                    }
                else {
                    // 입력받은 값이 dictionary의 key값으로 존재하지 않을 경우
                    // 값을 추가해주고 value 값을 1로 초기화해줌
                    print("Not exist")
                    self.items["\(self.getNameofItem!)"] = 1
                }
                self.itemListTableView.reloadData()
                print(self.items);
                self.reader.startScanning()
                
                
                //물품 리스트에 추가 할 때 마다 총 금액 정보 = 리로드(reload)
                
                
                print("glglgl")
                print(self.itemTotalPrice)
                self.addPrice? = Double(self.getPriceofItem!)!
                print(self.addPrice!)
                self.itemTotalPrice += (self.addPrice!)
                self.itemTotalPriceLabel.text = "\(self.itemTotalPrice)"
                self.viewDidLoad()
            }))
            
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                // Cancel 버튼.
                self.reader.startScanning()
            }))
            self.present(alertController, animated: true, completion: nil)
            

            //let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            //alertController.addAction(okAction)
            //let cancleAction =  UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
        }
        //reader.startScanning()
        
        //UIViewController?.present(alertController, animated: true, completion: nil)
        //UIViewController?.reloadInputViews()
    }
    
    

    //***********************************************************//
    //                                                           //
    //                                                           //
    //   QRscansession2                                          //
    //    -> value 튜플에 저장(url fragment)                        //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    ////qr이미지에서 URI받아오는겅~~~!~!~!~!~! 튜플로 URL을 쪼개서 변수에 저장
    var getNameofItem: String?
    var getPriceofItem: String?
    func scanQRinfo(getqrinfo: String!) {
        //let getqrinfo = result.value
        func generateDictionalyFromUrlComponents(components: NSURLComponents) -> [String : String] {
            var fragments: [String : String] = [:]
            guard let items = components.queryItems else {
                return fragments
            }
            
            for item in items {
                fragments[item.name] = item.value
            }
            
            return fragments
        }
        
    let comp: NSURLComponents? = NSURLComponents(string: getqrinfo!)
        let fragments = generateDictionalyFromUrlComponents(components: comp!)
        //        print(fragments["price"]) // => Optional("12345")
        getNameofItem = fragments["nameofItem"]
        getPriceofItem = fragments["priceofItem"]
        
      
    }
    
    
  
    
    //***********************************************************//
    //                                                           //
    //                                                           //
    //   Override function Lifecycle 짜증낭 😡                     //
    //                                                           //
    //                                                           //
    //***********************************************************//
    
    override func viewDidLoad() {
        super.viewDidLoad()
        qrScansession() //이 뷰 로드되면 qr카메라 자동 실행
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        //        reader.startScanning()
        
        //self.itemListTableView.reloadData()
        //itemListTableView = UITableView(frame: UIScreen.main.bounds, style: UITableViewStyle.plain)
        itemListTableView?.delegate = self          // Table cell과 관련된 콜백
        itemListTableView?.dataSource = self        // 데이터 관리와 관련된 콜백
        //self.itemListTableView.reloadData()
        //self.itemListTableView.register(UITableViewCell.self, forCellReuseIdentifier: "ItemListTableViewCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
   
   
    //hide qr camera T.T
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        self.reader.stopScanning()
//    }
    

    override func didReceiveMemoryWarning() {
        //super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}




