//
//  ChargingViewController.swift
//  userWalletapp
//
//  Created by 박신원 on 2018. 6. 15..
//  Copyright © 2018년 박신원. All rights reserved.
//

import UIKit
import Alamofire
import LocalAuthentication

class ChargingViewController: ViewController, UITextFieldDelegate {
    
    static let key = "HDmasterKey"
    static let tx_id = "tx_id"
    
    var hdKeyObject : String?
    var tx_idObj : String?
    
    @IBAction func inputtext(_ sender: Any) {
        textFieldShouldReturn(textField: chargingSumText)
    }
    @IBOutlet weak var chargingSumText: UITextField!
    
    //    @IBAction func chargingSumTextEditingDidEnd(_ sender: Any) {
    //
    //    }
    @IBAction func goCharge(_ sender: Any) {
        
        
        
       //alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in self?.performSegue(withIdentifier: "typeofPay", sender: self)
        
        
        let authContext = LAContext()
        var error: NSError?
        guard authContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            return
        }
        authContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "홈 버튼에 손가락을 올려주세요.", reply: { success, error in
            if success {
                // Fingerprint recognized
                //self.present(authContext, animated: true)
                
                self.tryCharging()
                self.performSegue(withIdentifier: "confirmChargingSegue", sender: self)
            } else {
                if let error = error {
                    print(error.localizedDescription)
                }
            }
        })
        
        
    }
    
    
    
    func tryCharging() {
        // 입력한 값을 double 형으로 받음
        let c_amount: Double? = Double(chargingSumText.text!)!
        
        // pubkey는 QR 코드를 통해 전송받은 값이 들어가야함
        let pubKey: String = "2MzuxoioVoGSJcp3rZyofVnLuVQFUm6uMSx";
        
        /*-----------------------------------------------------------------------------------
         
         :::WEB server에 url 전송:::
         
         try_charging.php 파일은 웹서버에 전송할 url을 통해 매개변수 값을 전달받음(코드확인)
         그렇기 때문에 앱에서 웹서버에 호출할 때 매개변수를 포함한 url 형태로 전송해야함
         
         -----------------------------------------------------------------------------------*/
        
        let _url = "http://10.90.1.241/try_charging.php"
        let parameters: Parameters = [
            
            "pubKey": pubKey,
            "amount": c_amount!
        ]
        Alamofire.request(_url,
                          method: .post,
                          parameters: parameters,
                          encoding: URLEncoding.queryString ).responseJSON{ response in
                            
                            // SUCCESS or FAILURE 값을 반환함. 주석처리해도 상관없음
                            print(response)
                            
                            if let tx_idJSON = response.result.value {
                                let tx_idObject:Dictionary = tx_idJSON as! Dictionary<String, Any>
                                
                                self.hdKeyObject = tx_idObject[ChargingViewController.key] as? String
                                self.tx_idObj = tx_idObject[ChargingViewController.tx_id] as? String
                                
                                
                                if(self.hdKeyObject != nil)
                                {
                                    print("I'M IN")
                                    let _url = "http://10.90.2.236/goUsertoDB2.php"
                                    let parameters: Parameters = [
                                        
                                        "HDmasterKey": self.hdKeyObject!,
                                        "tx_id" : self.tx_idObj!,
                                        "amount" : c_amount! //hidden
                                    ]
                                    
                                    Alamofire.request(_url,
                                                      method: .post,
                                                      parameters: parameters,
                                                      encoding: URLEncoding.queryString )
                                }
                                
                            }
                            
        }
        
        //result.text = "\(c_amount!)BTC 충전요청이 완료됐습니다."
        
    }
    
    //텍스트 입력시 키보드에 return버튼
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true;
    }
    
    // Text fields delegate
    func initializeTextFields() {
        
        chargingSumText.delegate = self
        // chargingSumText.keyboardType = UIKeyboardType.numberPad
        
        
    }
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print(segue.identifier!)
        
        let DestinationViewController : ChargingFinalViewController = segue.destination as! ChargingFinalViewController
        
        DestinationViewController.howMuchChargeText = chargingSumText.text!
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeTextFields()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
